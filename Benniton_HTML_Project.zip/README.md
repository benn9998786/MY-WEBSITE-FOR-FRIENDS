# My HTML Project

Welcome! This is a simple educational website made by **Benniton Fernandes** using HTML.

## 🌐 Pages Included

- `index.html` – Home page with links to my projects
- `school.html` – About Fr. Agnel Higher Secondary School
- `instruments.html` – Display of musical instruments (nested list)

## 🚀 Live Site

To be hosted on GitHub Pages.

## 📁 Project Created For

- Practical assignments in school
- HTML learning and demo
